// script.js
function clearDisplay() {
    document.getElementById('inputDisplay').value = '';
    document.getElementById('resultDisplay').value = '';
}

function deleteLast() {
    let inputDisplay = document.getElementById('inputDisplay');
    inputDisplay.value = inputDisplay.value.slice(0, -1);
}

function appendToDisplay(value) {
    let inputDisplay = document.getElementById('inputDisplay');
    inputDisplay.value += value;
}

function calculateResult() {
    let inputDisplay = document.getElementById('inputDisplay');
    let resultDisplay = document.getElementById('resultDisplay');
    try {
        resultDisplay.value = eval(inputDisplay.value);
    } catch (e) {
        resultDisplay.value = 'Error';
    }
}
